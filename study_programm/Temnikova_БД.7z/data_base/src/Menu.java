import Guest.StartMenu;
import Roles.*;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

public class Menu extends JFrame {
    Connection conn;
    public Menu(Connection conn_) {
        conn = conn_;
        setSize(700, 600);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel textTop = new JLabel("Выберите должность.");
        textTop.setVerticalAlignment(JLabel.TOP);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 1;
        gbc.gridwidth = 4;
        gbc.insets = new Insets(0, 0, 20, 0);
        panel.add(textTop, gbc);

        JButton b1 = new JButton("Администратор корпуса");
        b1.setPreferredSize(new Dimension(500,100));
        adminCorpus(b1);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridheight = 1;
        gbc.gridwidth = 4;
        gbc.insets = new Insets(0, 0, 10, 0);
        panel.add(b1, gbc);

        JButton b2 = new JButton("Дежурный администратор");
        b2.setPreferredSize(new Dimension(500,100));
        admin(b2);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridheight = 1;
        gbc.gridwidth = 4;
        gbc.insets = new Insets(0, 0, 10, 0);
        panel.add(b2, gbc);

        JButton b3 = new JButton("Агент по бронированию");
        b3.setPreferredSize(new Dimension(500,100));
        booking(b3);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridheight = 1;
        gbc.gridwidth = 4;
        gbc.insets = new Insets(0, 0, 10, 0);
        panel.add(b3, gbc);

        JButton b4 = new JButton("Кассир");
        b4.setPreferredSize(new Dimension(500,100));
        cash(b4);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridheight = 1;
        gbc.gridwidth = 4;
        gbc.insets = new Insets(0, 0, 0, 0);
        panel.add(b4, gbc);

        add(panel);
        setVisible(true);
    }

    private void adminCorpus(JButton button) {
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminCorpus(conn);
            }
        });
    }
    private void admin(JButton button) {
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Admin(conn);
            }
        });
    }
    private void booking(JButton button) {
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Booking(conn);
            }
        });
    }
    private void cash(JButton button) {
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new StartMenu(conn);
            }
        });
    }
}