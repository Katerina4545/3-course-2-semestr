package infRoom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class TimePeriod extends JFrame {
    Controller controller;
    private final JLabel start = new JLabel("");
    private final JLabel finish = new JLabel("");

    public TimePeriod(Controller controller_){
        controller = controller_;

        setSize(300, 220);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel textTop = new JLabel("Введите период в формате хх.хх.ххxx");
        textTop.setVerticalAlignment(JLabel.TOP);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 1;
        gbc.gridwidth = 4;
        gbc.insets = new Insets(0, 0, 10, 0);
        panel.add(textTop, gbc);

        JTextField jTextField1 = new JTextField(5);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridheight = 1;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 20, 20, 0);
        panel.add(jTextField1, gbc);

        JTextField jTextField2 = new JTextField(5);
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.gridheight = 1;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        panel.add(jTextField2, gbc);

        //запомнить выбор для jTextField
        ActionListener actionListenerComboBox = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JTextField textField = (JTextField) e.getSource();
                String text = textField.getText();
                start.setText(text);
            }
        };
        jTextField1.addActionListener(actionListenerComboBox);

        ActionListener actionListenerComboBox2 = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JTextField textField = (JTextField) e.getSource();
                String text = textField.getText();
                finish.setText(text);
            }
        };
        jTextField2.addActionListener(actionListenerComboBox2);

        JButton findButton = new JButton("Найти");
        addActionListenerFindButton(findButton);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0, 0, 0, 0);
        panel.add(findButton, gbc);

        add(panel);
        setVisible(true);
    }

    private void addActionListenerFindButton(JButton button) {
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //проверка корректности
                if(correct(start.getText())&&correct(finish.getText()))
                    //новое окно
                    new ListGuests(controller);
                else new HelpNote("period");
            }
        });
    }

    private boolean correct(String str){
        if(str.equals("")) return true;
        Pattern p = Pattern.compile("^([012][1-9]|[3][01])\\.([0][1-9]|[1][012])\\.(20[0-9][0-9]|2100)$");
        Matcher m = p.matcher(str);
        boolean res = m.find();
        return res;
    }
}
